from django.apps import AppConfig


class ConclusionConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'conclusion'
